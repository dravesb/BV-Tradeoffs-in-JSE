#--------------------------------------
#
#       Power Analaysis Figures
#           
#--------------------------------------
pacman::p_load('lattice', 'ggplot2', 'gridExtra', 'grid', 'dplyr', 'reshape2')

#read in data
df <- read.csv('~/Documents/Work/github/BJSE/power_analysis/data/plotting_df.csv')[,-1]
df <- df %>% mutate(W_hat_Rej_new = ifelse(W_hat > qchisq(1 - alpha, df = net_size * 2  + correction), 1, 0))

#set level
alpha <- 0.05

#power figure
plotdf <- as.data.frame(df[,c(1:3,9:12)]) %>%
  melt(id.vars = c(1:3)) %>%
  group_by(t, net_size, variable) %>% 
  summarize(power = mean(value), sd_power = 1.96*sd(value)/sqrt(n()))

ggplot(plotdf, aes(t, power, col = variable))+
  geom_ribbon(aes(ymin = power - sd_power,
                  ymax = power + sd_power),
              fill = 'grey', alpha = 0.8, linetype = 0)+
  geom_point(alpha = .5) + geom_line(alpha = 0.5)+
  geom_hline(yintercept = alpha, linetype = 'dashed', col = 'grey')+ 
  scale_color_manual(labels = c('T', 'W', expression(hat('W')), expression(tilde('W')))
                     , values = c('red', 'darkgreen', 'blue', 'purple')
                     )+
  facet_grid(cols = vars(net_size))+
  labs(x = 't', y = 'Empirical Power', color = 'Method')+
  theme_bw()

ggsave(filename = 'empirical_power.pdf', 
       width = 10, height = 5, 
       path = "~/Documents/Work/github/BJSE/power_analysis/figures/", 
       units = "in")

#visualize as a function of degrees of freedom
correction <- 10
df2 <- df %>% mutate(W_hat_Rej_new = ifelse(W_hat > qchisq(1 - alpha, df = net_size * 2  + correction), 1, 0))

#power figure
plotdf <- as.data.frame(df2[,c(1:3,9:10, 12)]) %>%
  melt(id.vars = c(1:3)) %>%
  group_by(t, net_size, variable) %>% 
  summarize(power = mean(value), sd_power = 1.96*sd(value)/sqrt(n()))

ggplot(plotdf, aes(t, power, col = variable))+
  geom_ribbon(aes(ymin = power - sd_power,
                  ymax = power + sd_power),
              fill = 'darkgrey', alpha = 0.8, linetype = 0)+
  geom_point(alpha = .5) + geom_line(alpha = 0.5)+
  geom_hline(yintercept = alpha, linetype = 'dashed', col = 'grey')+ 
  scale_color_manual(labels = c('T', 'W', expression(hat('W'))), values = c('red', 'darkgreen', 'blue'))+
  facet_grid(cols = vars(net_size))+
  labs(x = 't', y = 'Empirical Power', color = 'Method')+
  theme_bw()

